#!/usr/bin/env bash
set -e

. env.sh

exec "$@"