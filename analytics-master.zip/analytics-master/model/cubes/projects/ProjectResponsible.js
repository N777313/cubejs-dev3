cube(`ProjectResponsible`, {
  extends: UserEmployee
});
