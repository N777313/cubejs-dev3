cube(`Thread`, {
  sql: `
    SELECT 
        id,
        type
    FROM thread`,
  
  preAggregations: {
    // Pre-Aggregations definitions go here
    // Learn more here: https://cube.dev/docs/caching/pre-aggregations/getting-started  
  },
  
  joins: {
    ThreadMessage: {
      sql: `${CUBE}.id = ${ThreadMessage}.thread_id`,
      relationship: `hasMany`
    }
  },
  
  measures: {
    count: {
      type: `count`,
      drillMembers: [id]
    }
  },
  
  dimensions: {
    id: {
      sql: `id`,
      type: `number`,
      primaryKey: true
    }
  },
  
  dataSource: `default`
});
