cube(`VatsCallInternalEmployee`, {
  extends: Employees,
  title: "Звонки - Сотрудник АТС внутренний"
})